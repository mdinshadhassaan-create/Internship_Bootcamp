package com.example.demo.model;

// Enum for status
public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    COMPLETED,
    BLOCKED
}
